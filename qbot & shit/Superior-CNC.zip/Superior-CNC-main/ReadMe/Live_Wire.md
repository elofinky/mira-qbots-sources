# Live Wire Greek DLC Pack

- Price £15 Lifetime

# Features

1. Gradient tables
    - Allows Your `users`, `attacks` `sessions`, `ongoing` & `sessions listids` to have a gradient applied to make the overall aesthetic look nicer!

2. Title Spinner
    - Allows you too have a myra inspired title spinner added to your cnc!