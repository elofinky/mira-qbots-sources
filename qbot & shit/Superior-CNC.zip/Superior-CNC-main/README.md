# Superior-CNC
Skidded Atlantic CNC Leaked by faded aka storm api. Use this if u deadass have nothing else to use.
Here is how to setup this CNC! (CNC TUT BY GOATED)
---------------------------------------------------------------------------------------------------
-> Installing Dependencies.
1. sudo apt update
2. sudo apt install mysql-server
---------------------------------------------------------------------------------------------------
-> Setting Up MYSQL.
1. sudo mysql
2. CREATE DATABASE greek;
3. CREATE USER 'greek'@'localhost' IDENTIFIED BY '7474ji4j6ti0260ijm6j462';
4. GRANT ALL PRIVILEGES ON * . * TO 'greek'@'localhost';
5. FLUSH PRIVILEGES;
6. exit;
---------------------------------------------------------------------------------------------------
-> Connecting Database.
1. Edit "config.json" with your db details you created.
---------------------------------------------------------------------------------------------------
-> Starting Up The cnc.
1. chmod 777 *
2. sudo ./Greek
---------------------------------------------------------------------------------------------------
-> Screening The Cnc.
1. apt install screen
2. screen ./Greek
---------------------------------------------------------------------------------------------------
-> Information.
1. Enjoy this skidded atlantic cnc. Its unlicensed aswell, so use it however you want.
2. If your somehow still having trouble setting up pm me on instagram: @goated.py
